local isOff = (item == P:getOffhandItem(player))
local bl = isOff and -1 or 1
local l = bl
local d = isOff and -0.8 or 1

local items = {
	"minecraft:potion",
	"minecraft:splash_potion",
	"minecraft:lingering_potion",
	"minecraft:dragon_breath",
	"minecraft:experience_bottle",
	"minecraft:ominous_bottle",
	"minecraft:glass_bottle"
	
}

for i, id in pairs(items) do
	if I:isOf(item, Items:get(id)) and not P:isUsingItem(player) then
	M:scale(matrices, 0.95, 0.95, 0.95)
	M:rotateX(matrices, -150)
	M:rotateY(matrices, 20 * d)
	M:moveY(matrices, -0.20)
	M:rotateZ(matrices, 170 * l)
	M:moveX(matrices, 0.1 * l)
	M:moveZ(matrices, 0.05)
	end
end


if I:isOf(item, Items:get("minecraft:honey_bottle")) and not P:isUsingItem(player) then
	M:scale(matrices, 0.95, 0.95, 0.95)
	M:rotateX(matrices, -175)
	M:rotateY(matrices, 20 * d)
	M:rotateZ(matrices, 185 * l)
	M:moveY(matrices, 0.20)
	M:moveX(matrices, 0.05 * l)
	M:moveZ(matrices, -0.05)
end

if P:isUsingItem(player) and I:isOf(item, Items:get("minecraft:honey_bottle")) then
	M:scale(matrices, 1.0, 1.0, 1.0)
	M:rotateX(matrices, -70)
	M:rotateY(matrices, 0 * d)
	M:rotateZ(matrices, 20 * l)
	M:moveY(matrices, 0)
	M:moveX(matrices, 0.05 * l)
	M:moveZ(matrices, 0)
end

if P:isUsingItem(player) and I:isOf(item, Items:get("minecraft:ominous_bottle")) then
	M:scale(matrices, 1.0, 1.0, 1.0)
	M:rotateX(matrices, -70)
	M:rotateY(matrices, 0 * d)
	M:rotateZ(matrices, 20 * l)
	M:moveY(matrices, 0)
	M:moveX(matrices, 0.05 * l)
	M:moveZ(matrices, -0.1)
end

if P:isUsingItem(player) and I:isOf(item, Items:get("minecraft:potion")) then
	M:scale(matrices, 1.0, 1.0, 1.0)
	M:rotateX(matrices, -70)
	M:rotateY(matrices, 0 * d)
	M:rotateZ(matrices, 20 * l)
	M:moveY(matrices, 0)
	M:moveX(matrices, 0.05 * l)
	M:moveZ(matrices, 0)
end


