Version - 1.0b
This resourcepack made by CatFromNet

Project links:
    Modrinth → https://modrinth.com/resourcepack/rethoughted-dragon-egg
    CurseForge → https://curseforge.com/minecraft/texture-packs/rethoughted-dragon-egg

Feedback and social:
    Creator links → https://linktr.ee/catfromnet
    Discord server → https://discord.gg/q29y59SWEu
