Version - 1.0c
This resourcepack made by CatFromNet

Project links:
    Modrinth → https://modrinth.com/resourcepack/rethoughted-elytra
    CurseForge → https://www.curseforge.com/minecraft/texture-packs/rethoughted-elytra

Feedback and social:
    Creator links → https://linktr.ee/catfromnet
    Discord server → https://discord.gg/q29y59SWEu
