Rethoughted Trident
Version - 1.2
Made by CatFromNet

Project links:
• Modrinth — https://modrinth.com/resourcepack/rethoughted-trident
• CurseForge — https://www.curseforge.com/minecraft/texture-packs/rethoughted-trident

Feedback and socials:
• Creator links — https://linktr.ee/catfromnet
• Discord server — https://discord.gg/q29y59SWEu
